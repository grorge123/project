pip install gtts
pip install pyglet
pip install pyqt5
