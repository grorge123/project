求職小幫手
==========

這邊放的是求職小幫手的 Chrome extension 原始碼

關於求職小幫手的介紹可以看 [http://ronnywang.pixnet.net/blog/post/31872257](http://ronnywang.pixnet.net/blog/post/31872257)

另外相關討論可以到 [https://groups.google.com/forum/?fromgroups#!forum/twjobhelper](https://groups.google.com/forum/?fromgroups#!forum/twjobhelper)
